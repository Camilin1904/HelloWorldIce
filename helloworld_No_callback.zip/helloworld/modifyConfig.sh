pscp.exe -pw swarch configFiles/2/config.client  swarch@xhgrid2:/home/swarch/Documents/CarmonaLibreros/
pscp.exe -pw swarch configFiles/3/config.client  swarch@xhgrid3:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/4/config.client  swarch@xhgrid4:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/5/config.client  swarch@xhgrid5:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/6/config.client  swarch@xhgrid6:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/7/config.client  swarch@xhgrid7:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/8/config.client  swarch@xhgrid8:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/9/config.client  swarch@xhgrid9:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/10/config.client  swarch@xhgrid10:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/11/config.client  swarch@xhgrid11:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/13/config.client  swarch@xhgrid13:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/15/config.client  swarch@xhgrid15:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/17/config.client  swarch@xhgrid17:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch configFiles/21/config.client  swarch@xhgrid21:/home/swarch/Documents/CarmonaLibreros/   
pscp.exe -pw swarch configFiles/22/config.client  swarch@xhgrid22:/home/swarch/Documents/CarmonaLibreros/

pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid2:/home/swarch/Documents/CarmonaLibreros/META-INF/
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid3:/home/swarch/Documents/CarmonaLibreros/META-INF/
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid4:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid5:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid6:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid7:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid8:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid9:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid10:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid11:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid13:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid15:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid17:/home/swarch/Documents/CarmonaLibreros/META-INF/    
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid21:/home/swarch/Documents/CarmonaLibreros/META-INF/   
pscp.exe -pw swarch MANIFEST.MF  swarch@xhgrid22:/home/swarch/Documents/CarmonaLibreros/META-INF/



plink.exe -ssh swarch@xhgrid2 -pw swarch  -m putFiles.sh
plink.exe -ssh swarch@xhgrid3 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid4 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid5 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid6 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid7 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid8 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid9 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid10 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid11 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid13 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid15 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid17 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid21 -pw swarch  -m putFiles.sh  
plink.exe -ssh swarch@xhgrid22 -pw swarch  -m putFiles.sh