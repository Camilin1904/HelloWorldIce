cd Documents
mkdir CarmonaLibreros
mkdir CarmonaLibreros/META-INF