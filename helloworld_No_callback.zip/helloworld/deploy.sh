# plink.exe -ssh swarch@xhgrid2 -pw swarch  -m mkdir.sh
# plink.exe -ssh swarch@xhgrid3 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid4 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid5 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid6 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid7 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid8 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid9 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid10 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid11 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid13 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid15 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid17 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid21 -pw swarch  -m mkdir.sh  
# plink.exe -ssh swarch@xhgrid22 -pw swarch  -m mkdir.sh

pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid2:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid3:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid4:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid5:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid6:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid7:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid8:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid9:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid10:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid11:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid13:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid15:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid17:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid21:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch client/build/libs/client.jar  swarch@xhgrid22:/home/swarch/Documents/CarmonaLibreros/ 
 
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid2:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid3:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid4:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid5:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid6:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid7:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid8:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid9:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid10:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid11:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid13:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid15:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid17:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid21:/home/swarch/Documents/CarmonaLibreros/    
pscp.exe -pw swarch ice-3.7.6.jar  swarch@xhgrid22:/home/swarch/Documents/CarmonaLibreros/   