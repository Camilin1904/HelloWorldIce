cd Documents/CarmonaLibreros

jar uf client.jar config.client 
jar ufm client.jar META-INF/MANIFEST.MF  