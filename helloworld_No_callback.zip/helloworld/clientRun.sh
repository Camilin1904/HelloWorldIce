#!/usr/bin/expect -f
cd Documents/CarmonaLibreros

simulateClient(){
    echo "10000"  
    wait
    echo "exit"
}

simulateClient | java -jar client.jar
